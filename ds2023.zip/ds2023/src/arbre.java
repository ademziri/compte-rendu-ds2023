public class arbre extends plante {
    private String typef;
    private static final double absorm=22;

    public arbre(String nom,int hauteur,int age,int prix,String typef ) {
        super(nom,hauteur,age,prix);
        this.typef=typef;
    }

    public String toString() {
        return super.toString()+" "+typef+" "+absorm;
    }


    public void description() {
        System.out.println(toString());
    }

    public double absorptionCO2(){
        if (hauteur>50){
            return absorm+3;
        }

        else {
            return absorm;
        }
    }

    public boolean estcadeque(){
        if(typef.equals("cadeque")){
            return true;
        }
        else {
            return false;
        }
    }


}
