public class pepiniere {
    private plante[] inventaire;
    private static final int maxp=1000;
    private static int nbrp=0;



    public void ajoutplante(plante plante) {
        nbrp++;
        if(nbrp<maxp){
            inventaire[nbrp] = plante;
        }
        else{
            System.out.println("l'inventaire est plein");
        }
    }

    public void afficherinventaire() {
        for(int i=0;i<nbrp;i++){
            inventaire[i].description();
        }
    }

    public double totalabsorption(){
        double s=0;
        for(int i=0;i<nbrp;i++){
            if(inventaire[i] instanceof arbre) {
                s += ((arbre) inventaire[i]).absorptionCO2();
            }
        }
        return s;
    }

    public double compterarbrec(){
        double total=0;
        for(int i=0;i<nbrp;i++){
            if(inventaire[i] instanceof arbre) {
                if(((arbre) inventaire[i]).estcadeque()){
                    total += ((arbre) inventaire[i]).absorptionCO2();
                }
            }
        }
        return total;
    }



}
