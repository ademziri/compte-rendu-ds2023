public class fleur extends plante{
    private String couleur;
    private int moisf;

    public fleur(String nom, int hauteur, int age, int prix, String couleur, int moisf){
        super(nom, hauteur, age, prix);
        this.couleur = couleur;
        this.moisf = moisf;
    }

    public String toString(){
        return super.toString()+" couleur "+couleur+" moisf "+moisf;
    }

    public void description(){
        System.out.println(toString());
    }

    public String getCouleur() {
        return couleur;
    }

    public void fleurir(){
        if (moisf==4 || moisf==5 || moisf==6 ){
            System.out.println("la fleur est en fleurs");
        }
        else{
            System.out.println("la fleur est pas en fleurs");
        }
    }



}
