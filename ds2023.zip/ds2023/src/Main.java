public class Main {
    public static void main(String[] args) {
        System.out.println("          pepiniere GREEN HANDS");
        pepiniere pepiniere = new pepiniere();

        fleur rose = new fleur(null, 30, 12, 15, "Rouge", 2);
        fleur tulipe = new fleur("Tulipe", 20, 8, 12, "Jaune", 4);
        arbre chêne = new arbre("Chêne", 200, 600, 89, "Caduc");
        arbre sapin = new arbre("Sapin", 150, 30, 59, "Persistant");

        rose.setNom("Rose");
        System.out.println("La " + rose.getNom() + " a le couleur " + rose.getCouleur());

        pepiniere.ajoutplante(rose);
        pepiniere.ajoutplante(tulipe);
        pepiniere.ajoutplante(chêne);
        pepiniere.ajoutplante(sapin);

        pepiniere.afficherinventaire();

        System.out.println("Total Absorption CO2 : " + pepiniere.totalabsorption());
        System.out.println("Nombre d'arbres Caduques dans la pepiniere : " + pepiniere.compterarbrec());
    }

}